hElLo
To run pingerjuice please give it admin befor running pranked.bat thanks
need to talk to me click on the discord link!
wanna donate dm me!